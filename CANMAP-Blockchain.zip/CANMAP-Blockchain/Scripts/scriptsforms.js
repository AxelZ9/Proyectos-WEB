
let ip = 'http://127.0.0.1:5000'
let =""

var inputFileToLoad = document.getElementById("foto");
inputFileToLoad.addEventListener("change", function(){

    encodeImageFile()
  });


function encodeImageFile() {
    var filesSelected = document.getElementById("foto").files;

    if (filesSelected.length > 0) {

        var fileReader = new FileReader();
        
        fileReader.onload = function(fileLoadedEvent) {
            var srcData = fileLoadedEvent.target.result; // <--- data: base64
            srcData.replace(/^data:image\/[a-z]+;base64,/, "");

            images=  srcData
        }
    }
}


function new_transaction(nombrePerro, foto_in_Base64,timestamp_act,Vacunado,Esterilizado,Estado,ubicacion){
    fetch(ip+'/transactions/new', {
        method: 'POST',
        headers: {Accept: 'application/json','Content-Type': 'application/json'},
        body: JSON.stringify({ nombre_perro: nombrePerro, foto_in_Base64: foto_in_Base64, timestamp_act: timestamp_act , Vacunado: Vacunado ,Esterilizado: Esterilizado,  Estado: Estado, ubicacion:ubicacion})
    })
    .then(response => {
        if (response.ok) {
            alert('Estado del perro fue registrado correctamente');
        } else {
            alert('Error al registrar el estado del perro');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
} 
document.addEventListener('DOMContentLoaded', function () {
    const new_dog = document.getElementById('new');
    new_dog.addEventListener('click', function () {
        //encodeImageFile()
        const nombrePerro = document.getElementById('nombre').value;
        console.log(nombrePerro)
        const foto_in_Base64= "########"
        const timestamp_act = Date.now()
        const Vacunado = document.getElementById('vacunado').value;
        const Esterilizado = document.getElementById('esterilizado').value;
        const Estado = document.getElementById('estado').value;
        const ubicacion =document.getElementById('ubicacion').value;
        new_transaction(nombrePerro, foto_in_Base64,timestamp_act,Vacunado,Esterilizado,Estado,ubicacion);
    });

});