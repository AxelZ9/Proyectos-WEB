
//Abrir Pestaña de informacion del lomito
/*
document.addEventListener('DOMContentLoaded', function () {
    const Back = document.getElementById('Back');

    Back.addEventListener('click', function () {
        window.location.href = "/index.html";
    });

});
*/
document.getElementById("Back").addEventListener("click", function(){
    window.location.href = "/index.html"; 
});