
document.addEventListener('DOMContentLoaded', function () {
    const updateStatusBtn = document.getElementById('updateStatusBtn');
    const statusMenu = document.getElementById('statusMenu');
    const updateLocationBtn = document.getElementById('updateLocationBtn');

    updateStatusBtn.addEventListener('click', function () {
        statusMenu.classList.toggle('hidden');
    });

    const statusOptions = document.querySelectorAll('.status-option');
    statusOptions.forEach(option => {
        option.addEventListener('click', function () {
            const status = this.getAttribute('data-status');
            const nombrePerro = document.getElementById('nombrePerro').innerText;
            actualizarEstadoPerro(nombrePerro, status);
            statusMenu.classList.add('hidden');
        });
    });
    updateLocationBtn.addEventListener('click', function () {
        const nuevaUbicacion = document.getElementById('ubicacion').value;
        const nombrePerro = document.getElementById('nombrePerro').innerText;
        actualizarUbicacionPerro(nombrePerro, nuevaUbicacion);
        
    });
});
let ip = 'http://127.0.0.1:5000'

function actualizarEstadoPerro(nombrePerro, nuevoEstado) {
    data= get_transaction(nombrePerro)
    console.log("cual?   "+data)
    fetch(ip+'/transactions/new', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nombre_perro: nombrePerro, foto_in_Base64 : "data/fnsnfsfenfsef" ,timestamp_act:183773847884.484994 , Vacunado: true ,Esterilizado: true,  Estado: nuevoEstado, ubicacion:"cutonala"})
    })
    .then(response => {
        if (response.ok) {
            alert('Estado del perro actualizado correctamente');
        } else {
            alert('Error al actualizar el estado del perro');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
} 


function actualizarUbicacionPerro(nombrePerro, nuevaUbicacion) {
    fetch(ip+'/transactions/update_location', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  nombre_perro: nombrePerro, foto_in_Base64:"data/fuiefsnfesnfosnfosf" ,timestamp_act:1637389273.48383 , Vacunado: True ,Esterilizado: True,  Estado: "En buen estado", ubicacion:nuevaUbicacion})
    })
    .then(response => {
        if (response.ok) {
            alert('Ubicación del perro actualizada correctamente');
        } else {
            alert('Error al actualizar la ubicación del perro');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function getChain(){
    fetch(ip+'/chain', {
        method: 'GET',
    }).then((response) => response.json())
    .then(_data => {
        return _data
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function getallTransactions(){
    fetch(ip+'/transactions/get_all', {
        method: 'GET',
    }).then((response) => response.json())
    .then(_data => {
        return _data
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

//El input es un array
async function get_transaction(name){
    try{
    const response = await fetch(ip+'/transactions/get', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  'names': name })
    });
    if(!response.ok){
        throw new Error(`HTTP error ${response.status}`);
    }
    return json = await response.json();
    
    }catch(error){
        console.log(error)
    }
    
}
