let tipoViviendaSeleccionada;
let nombreCasaIngresado;

function agregarCasa() {
    tipoViviendaSeleccionada = document.getElementById("tipoVivienda").value;
    nombreCasaIngresado = document.getElementById("nombreCasa").value;
    mostrarFormularioFocos();
}

function mostrarFormularioFocos() {
    document.getElementById("formularioAgregarCasa").style.display = "none";
    document.getElementById("formularioConfigurarFocos").style.display = "block";

    // Muestra la información de la casa en la parte superior de la calculadora
    const infoCasaDiv = document.getElementById("infoCasa");
    infoCasaDiv.style.display = "block";
    infoCasaDiv.innerHTML = `<p>Tipo de Vivienda: ${tipoViviendaSeleccionada}</p><p>Nombre: ${nombreCasaIngresado}</p>`;
}

function calcularConsumo() {
    // Mostrar el formulario de configuración de focos si no está visible
    if (document.getElementById("formularioConfigurarFocos").style.display === "none") {
        mostrarFormularioFocos();
    }

    // Luego, obtener los valores
    const tipoFoco = document.getElementById("tipoFoco").value;
    const tiempo = document.getElementById("tiempo").value;
    const cantidadFocos = parseInt(document.getElementById("cantidadFocos").value, 10);
    const horasUsoDiario = parseInt(document.getElementById("horasUsoDiario").value, 10);
    document.getElementById("resultado").style.display = "block";

    // Resto del código de calcularConsumo...
    const potenciaFoco = {
        incandescente: 60,
        led: 10,
        halogeno: 50,
        ahorrador: 13,
        fluorescente: 32,
        inteligente: 10
    };

    const horasPorTiempo = {
        dia: 24,
        semana: 24 * 7,
        mes: 24 * 30,
        bimestre: 24 * 30 * 2,
        ano: 24 * 365
    };

    const potenciaEnWatts = potenciaFoco[tipoFoco];
    const tiempoEnHoras = horasPorTiempo[tiempo];
    const consumoEnKwh = (potenciaEnWatts * horasUsoDiario * cantidadFocos * tiempoEnHoras) / 1000;

    const costoBasicoPorKwh = 1.005;
    const costoIntermedioPorKwh = 1.227;
    const costoExcedentePorKwh = 3.584;
    const limiteBasicoKwh = 75;
    const limiteIntermedioKwh = 65;

    let costoTotal = 0;

    if (consumoEnKwh <= limiteBasicoKwh) {
        costoTotal = consumoEnKwh * costoBasicoPorKwh;
    } else if (consumoEnKwh <= limiteBasicoKwh + limiteIntermedioKwh) {
        costoTotal = (limiteBasicoKwh * costoBasicoPorKwh) +
            ((consumoEnKwh - limiteBasicoKwh) * costoIntermedioPorKwh);
    } else {
        costoTotal = (limiteBasicoKwh * costoBasicoPorKwh) +
            (limiteIntermedioKwh * costoIntermedioPorKwh) +
            ((consumoEnKwh - limiteBasicoKwh - limiteIntermedioKwh) * costoExcedentePorKwh);
    }

    const resultado = `
        <p>Consumo en ${tiempo}: ${consumoEnKwh.toFixed(2)} kWh</p>
        <p>Costo: ${costoTotal.toFixed(2)} pesos MXN</p>
    `;

    document.getElementById("resultado").innerHTML = resultado;
}