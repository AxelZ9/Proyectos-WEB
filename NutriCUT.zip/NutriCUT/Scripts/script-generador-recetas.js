const ingredientInput = document.getElementById('ingredient-input');
const ingredientList = document.getElementById('ingredient-list');
const recipeList = document.getElementById('recipe-list');

function addIngredient() {
    const ingredient = ingredientInput.value.trim();
    if (ingredient !== '') {
        const li = document.createElement('li');
        li.textContent = ingredient;
        ingredientList.appendChild(li);
        ingredientInput.value = '';
    }
}

// Ejemplo de recetas (puedes sustituir con tus propias recetas)
const recipes = [
    { name: 'Ensalada César', ingredients: ['Lechuga', 'Pollo', 'Crutones', 'Aderezo César'] },
    { name: 'Espagueti a la Boloñesa', ingredients: ['Espagueti', 'Carne molida', 'Tomate', 'Cebolla', 'Ajo'] },
    { name: 'Tacos de Pollo', ingredients: ['Tortillas de maíz', 'Pollo', 'Cilantro', 'Cebolla', 'Salsa'] }
];

function generateRecipes() {
    recipeList.innerHTML = '';
    const availableIngredients = Array.from(document.querySelectorAll('#ingredient-list li')).map(li => li.textContent);
    recipes.forEach(recipe => {
        const ingredientsMatched = recipe.ingredients.filter(ingredient => availableIngredients.includes(ingredient));
        if (ingredientsMatched.length === recipe.ingredients.length) {
            const li = document.createElement('li');
            li.textContent = recipe.name;
            recipeList.appendChild(li);
        }
    });
}

generateRecipes();
