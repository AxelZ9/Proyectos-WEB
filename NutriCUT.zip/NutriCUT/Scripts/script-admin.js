// Simulación de datos
const usuarios = [
    { nombre: 'Usuario 1', correo: 'usuario1@example.com' },
    { nombre: 'Usuario 2', correo: 'usuario2@example.com' }
  ];
  
  const recetas = [
    { titulo: 'Receta 1', categoria: 'Desayuno' },
    { titulo: 'Receta 2', categoria: 'Almuerzo' }
  ];
  
  // Función para cargar usuarios
  function cargarUsuarios() {
    const usuariosTabla = document.getElementById('usuariosTabla');
    usuariosTabla.innerHTML = '';
    usuarios.forEach(usuario => {
      const fila = `
        <tr>
          <td>${usuario.nombre}</td>
          <td>${usuario.correo}</td>
          <td>
            <button class="btn btn-danger btn-sm" onclick="eliminarUsuario('${usuario.nombre}')">Eliminar</button>
          </td>
        </tr>
      `;
      usuariosTabla.innerHTML += fila;
    });
  }
  
  // Función para cargar recetas
  function cargarRecetas() {
    const recetasTabla = document.getElementById('recetasTabla');
    recetasTabla.innerHTML = '';
    recetas.forEach(receta => {
      const fila = `
        <tr>
          <td>${receta.titulo}</td>
          <td>${receta.categoria}</td>
          <td>
            <button class="btn btn-danger btn-sm" onclick="eliminarReceta('${receta.titulo}')">Eliminar</button>
          </td>
        </tr>
      `;
      recetasTabla.innerHTML += fila;
    });
  }
  
  // Función para agregar usuario (simulación)
  function agregarUsuario() {
    // Aquí puedes implementar la lógica para agregar un usuario
    alert('Función de agregar usuario aún no implementada');
  }
  
  // Función para agregar receta (simulación)
  function agregarReceta() {
    // Aquí puedes implementar la lógica para agregar una receta
    alert('Función de agregar receta aún no implementada');
  }
  
  // Función para eliminar usuario
  function eliminarUsuario(nombreUsuario) {
    // Aquí puedes implementar la lógica para eliminar un usuario
    alert(`Eliminar usuario: ${nombreUsuario}`);
  }
  
  // Función para eliminar receta
  function eliminarReceta(tituloReceta) {
    // Aquí puedes implementar la lógica para eliminar una receta
    alert(`Eliminar receta: ${tituloReceta}`);
  }
  
  // Cargar usuarios y recetas al cargar la página
  window.onload = () => {
    cargarUsuarios();
    cargarRecetas();
  };
  