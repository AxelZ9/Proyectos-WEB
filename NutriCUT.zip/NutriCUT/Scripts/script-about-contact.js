const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');
const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#formulario input');
const mainContent = document.querySelector(".main-content");


const dialog = document.querySelector("dialog");
const closeDialogBtn = document.getElementById("close_dialog");
const closeDialog = (e) => {
	e.preventDefault();
	dialog.close();
};

closeDialogBtn.addEventListener("click", closeDialog);

registerLink.addEventListener('click', ()=> {
    wrapper.classList.add('active');
	mainContent.style.display = "none";
});

loginLink.addEventListener('click', ()=> {
    wrapper.classList.remove('active');
	mainContent.style.display = "none";
});

btnPopup.addEventListener('click', ()=> {
    wrapper.classList.add('active-popup');
	mainContent.style.display = "none";
});

iconClose.addEventListener('click', ()=> {
    wrapper.classList.remove('active-popup');
	mainContent.style.display = "block";
});