document.addEventListener('DOMContentLoaded', function() {
    const recetas = document.querySelectorAll('.receta');

    recetas.forEach(receta => {
        receta.addEventListener('dragstart', dragStart);
        receta.addEventListener('dragend', dragEnd);
    });

    function dragStart(e) {
        this.classList.add('dragging');
    }

    function dragEnd(e) {
        this.classList.remove('dragging');
    }

    const contenedoresDia = document.querySelectorAll('.dia-contenedor');

    contenedoresDia.forEach(contenedor => {
        contenedor.addEventListener('dragover', dragOver);
        contenedor.addEventListener('dragenter', dragEnter);
        contenedor.addEventListener('dragleave', dragLeave);
        contenedor.addEventListener('drop', drop);
    });

    function dragOver(e) {
        e.preventDefault();
    }

    function dragEnter(e) {
        e.preventDefault();
        this.classList.add('hovered');
    }

    function dragLeave() {
        this.classList.remove('hovered');
    }

    function drop() {
        this.classList.remove('hovered');
        const recetaArrastrada = document.querySelector('.dragging');
        this.appendChild(recetaArrastrada.cloneNode(true));
    }
});
